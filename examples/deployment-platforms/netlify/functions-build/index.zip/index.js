const path = require('path')
//@ts-check
const fs = require('fs')
const Photon = require('./generated/photon')

const binaryPath =
  process.env.BINARY_PATH === 'prisma-linux-lambda'
    ? path.join(__dirname, './prisma-linux-lambda')
    : path.join(__dirname, './prisma-mac')

const photon = new Photon.default({
  debug: true,
  __internal: {
    engine: {
      cwd: path.join(__dirname, 'prisma'),
      binaryPath,
    },
  },
})

exports.handler = async function(event, context, callback) {
  console.log({
    __dirname,
    binaryName: process.env.BINARY_PATH,
    processCwd: process.cwd(),
  })
  try {
    const files = fs.readdirSync('/var/task')
    console.log({ files })
  } catch (e) {}
  console.log({ binaryPath })
  const users = await photon.strapiAdministrators()
  console.log({ users })
  return {
    statusCode: 200,
    body: `users: ${JSON.stringify(users)}`,
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
  }
}
