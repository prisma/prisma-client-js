declare const browserChalk: any;
export default browserChalk;
