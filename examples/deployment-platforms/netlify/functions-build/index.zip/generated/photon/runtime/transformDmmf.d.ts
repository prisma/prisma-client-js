import { DMMF } from './dmmf-types';
export declare function transformDmmf(document: DMMF.Document): DMMF.Document;
