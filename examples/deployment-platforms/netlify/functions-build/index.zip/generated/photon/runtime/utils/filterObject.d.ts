export declare function filterObject(obj: any, cb: any): any;
