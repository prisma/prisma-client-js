export declare function dedent(str: string): string;
