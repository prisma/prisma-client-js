export declare const deepGet: (o: any, kp: string[], d?: any) => any;
export declare const deepSet: (o: any, kp: string | string[], v: any) => any;
