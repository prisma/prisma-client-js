declare const _default: (text: any, link: any) => any;
export default _default;
