declare const stringifyObject: (input: any, options?: any, pad?: any) => any;
export default stringifyObject;
